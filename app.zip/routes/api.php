<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

// Import semua Controller agar rapi
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\ProjekController;
use App\Http\Controllers\Api\ModulController;
use App\Http\Controllers\Api\KegiatanController;
use App\Http\Controllers\Api\TugasController;
use App\Http\Controllers\Api\LogbookController;
use App\Http\Controllers\Api\KategoriController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

// =========================================================================
// 1. PUBLIC ROUTES (Bisa diakses tanpa Token)
// =========================================================================
Route::post('login', [AuthController::class, 'login']);
// Public registration endpoint (create user)
Route::post('register', [UserController::class, 'store']);


// =========================================================================
// 2. PROTECTED ROUTES (Wajib menyertakan Token Bearer)
// =========================================================================
Route::middleware('auth:sanctum')->group(function () {

    // --- AUTHENTICATION & PROFILE ---
    Route::post('logout', [AuthController::class, 'logout']);
    Route::get('me', [AuthController::class, 'me']);

    // Helper bawaan Laravel untuk cek user (return resource for consistent shape)
    Route::get('/user', function (Request $request) {
        return new \App\Http\Resources\UserResource($request->user());
    });

    // --- CORE RESOURCES (FULL CRUD) ---

    Route::apiResource('users', UserController::class);
    Route::apiResource('projek', ProjekController::class);
    Route::apiResource('modul', ModulController::class);
    Route::apiResource('tugas', TugasController::class);

    // --- KEGIATAN (PARTIAL CRUD) ---
    Route::get('kegiatan', [KegiatanController::class, 'index']);
    Route::post('kegiatan', [KegiatanController::class, 'store']);
    Route::put('kegiatan/{id}', [KegiatanController::class, 'update']);
    Route::delete('kegiatan/{id}', [KegiatanController::class, 'destroy']);

    // --- LOGBOOK ---
    Route::get('logbook', [LogbookController::class, 'index']);
    Route::post('logbook', [LogbookController::class, 'store']);
    Route::put('logbook/{id}', [LogbookController::class, 'update']);
    Route::get('projek/{id}/logbook', [LogbookController::class, 'getByProject']);
    Route::get('logbook/task-progress/{tgsId}', [LogbookController::class, 'taskProgress']);


    // --- PROJEK SPECIFIC LOGIC (DASHBOARD) ---
    Route::get('/projek/{id}/stats', [ProjekController::class, 'getDashboardStats']);
    Route::get('/projek/{id}/breakdown', [ProjekController::class, 'getProjectBreakdown']);
    Route::post('/projek/{id}/recalculate', [ProjekController::class, 'recalculateProgress']);
    Route::get('/projek/{id}/members', [App\Http\Controllers\Api\ProjekController::class, 'getMembers']);

    Route::post('/profile/update', [UserController::class, 'update']);

    // === RUTE BARU UNTUK MEMBER ===
    Route::get('/projek/{id}/member', [ProjekController::class, 'getMembers']);
    Route::post('/projek/{id}/member', [ProjekController::class, 'addMember']);
    Route::put('/projek/{id}/member/{member_id}', [ProjekController::class, 'updateMember']);
    Route::delete('/projek/{id}/member/{member_id}', [ProjekController::class, 'removeMember']);

    Route::get('/kategori', [KategoriController::class, 'index']);
    Route::post('/kategori', [KategoriController::class, 'store']);
    Route::get('/kategori/{id}', [KategoriController::class, 'show']);
    Route::put('/kategori/{id}', [KategoriController::class, 'update']);
    Route::delete('/kategori/{id}', [KategoriController::class, 'destroy']);
    Route::patch('/kategori/{id}/toggle-status', [KategoriController::class, 'toggleStatus']);

    // === RUTE BARU UNTUK DROPDOWN USER ===
    Route::get('/users', [ProjekController::class, 'getUsers']);
});
